// 要素の取得
const textElement = document.getElementById('myText');
const changeTextButton = document.getElementById('changeTextButton');
const changeColorButton = document.getElementById('changeColorButton');

// テキストの変更
changeTextButton.addEventListener('click', function() {
    textElement.textContent = 'テキストが変更されました！';
});

// スタイルの変更
changeColorButton.addEventListener('click', function() {
    textElement.style.color = 'red';
});
