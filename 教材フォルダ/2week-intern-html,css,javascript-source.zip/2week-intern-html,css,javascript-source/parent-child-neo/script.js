const parent = document.getElementById('parent');
const firstChild = parent.querySelector('.child'); // 最初の子要素を取得
const allChildren = parent.querySelectorAll('.child'); // すべての子要素を取得

console.log(firstChild.textContent); 
console.log(allChildren.length); 



const addChildButton = document.getElementById('addChild');

addChildButton.addEventListener('click', () => {
    const newChild = document.createElement('p');
    newChild.textContent = '新しい子要素';
    newChild.className = 'child';
    parent.appendChild(newChild);
});




const removeChildButton = document.getElementById('removeChild');

removeChildButton.addEventListener('click', () => {
    const lastChild = parent.querySelector('.child:last-child');
    if (lastChild) {
        parent.removeChild(lastChild);
    }
});



