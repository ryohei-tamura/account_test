fetch('http://localhost:3000/weather')
    .then(response => {
        return response.json()
    }
    ).then(data => {

        const weatherElement = document.getElementById('weather');
        weatherElement.textContent = `${data.city}の天気は ${data.weather} で、気温は ${data.temperature} 度です。`;
    })
    .catch(error => {
        // エラーが発生した場合の処理
        const weatherElement = document.getElementById('weather');
        weatherElement.textContent = '天気情報を取得できませんでした。';
        console.error('エラーが発生しました:', error);
    });






fetch('http://localhost:3000/books')
    .then(response => response.json())
    .then(data => {

        const bookListElement = document.getElementById('book-list');

        data.forEach(book => {
            const listItem = document.createElement('li');
            listItem.textContent = `${book.title}（${book.author} 著, ${book.year} 年）`;
            bookListElement.appendChild(listItem);
        });
    })
    .catch(error => {
        // エラーが発生した場合の処理
        const bookListElement = document.getElementById('book-list');
        bookListElement.textContent = '書籍情報を取得できませんでした。';
        console.error('エラーが発生しました:', error);
    });