// HTMLに出力するための関数
function output(text) {
    const outputDiv = document.getElementById('output');
    outputDiv.innerHTML += `<p>${text}</p>`;
}

// 1. 従来の関数宣言 (Function Declaration)
function greet(name) {
    return `Hello, ${name}!`;
}

output(greet("Alice")); 
// 出力: Hello, Alice!

// 2. 関数式 (Function Expression)
const sum = function (a, b) {
    return a + b;
};

output(`Sum: ${sum(2, 3)}`);
// 出力: Sum: 5

// 3. アロー関数 (Arrow Function)
const multiply = (a, b) => {
    return a * b;
};

output(`Multiply: ${multiply(4, 5)}`);
 // 出力: Multiply: 20

// アロー関数の短縮形
const subtract = (a, b) => a - b;

output(`Subtract: ${subtract(10, 4)}`); 
// 出力: Subtract: 6

// 4. IIFE (Immediately Invoked Function Expression)
(function () {
    output("This is an IIFE");
})();
 // 出力: This is an IIFE

// 5. メソッドとしての関数
const calculator = {
    add: function (a, b) {
        return a + b;
    },
    subtract(a, b) {
        return a - b;
    }
};

output(`Calculator Add: ${calculator.add(7, 3)}`); 
// 出力: Calculator Add: 10
output(`Calculator Subtract: ${calculator.subtract(7, 3)}`); 
// 出力: Calculator Subtract: 4

// 6. コールバック関数
function doOperation(a, b, operation) {
    return operation(a, b);
}

const result = doOperation(5, 3, multiply);
output(`Callback Operation (Multiply): ${result}`); 
// 出力: Callback Operation (Multiply): 15

// 7. 関数のデフォルト引数
function greetWithDefault(name = "Guest") {
    return `Hello, ${name}!`;
}

output(greetWithDefault()); 
// 出力: Hello, Guest!
output(greetWithDefault("Bob")); 
// 出力: Hello, Bob!



// 8. 再帰関数 (Recursive Function)
function factorial(n) {
    if (n === 0) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

output(`Factorial of 5: ${factorial(5)}`); 
// 出力: Factorial of 5: 120
